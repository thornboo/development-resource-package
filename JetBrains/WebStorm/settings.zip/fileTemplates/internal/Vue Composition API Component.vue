<template>
  #[[$END$]]#
</template>

<script setup${SCRIPT_LANG_ATTR}>

</script>

<style scoped${STYLE_LANG_ATTR}>

</style>